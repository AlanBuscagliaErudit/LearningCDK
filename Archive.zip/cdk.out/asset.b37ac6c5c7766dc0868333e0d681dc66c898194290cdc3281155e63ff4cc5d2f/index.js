"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/server/server.ts
var server_exports = {};
__export(server_exports, {
  handler: () => handler,
  middleware: () => middleware,
  publicProcedure: () => publicProcedure,
  router: () => router
});
module.exports = __toCommonJS(server_exports);

// node_modules/@trpc/server/dist/TRPCError-7de0a793.mjs
function getMessageFromUnknownError(err, fallback) {
  if (typeof err === "string") {
    return err;
  }
  if (err instanceof Error && typeof err.message === "string") {
    return err.message;
  }
  return fallback;
}
function getErrorFromUnknown(cause) {
  if (cause instanceof Error) {
    return cause;
  }
  const message = getMessageFromUnknownError(cause, "Unknown error");
  return new Error(message);
}
function getTRPCErrorFromUnknown(cause) {
  const error = getErrorFromUnknown(cause);
  if (error.name === "TRPCError") {
    return cause;
  }
  const trpcError = new TRPCError({
    code: "INTERNAL_SERVER_ERROR",
    cause: error,
    message: error.message
  });
  trpcError.stack = error.stack;
  return trpcError;
}
function getCauseFromUnknown(cause) {
  if (cause instanceof Error) {
    return cause;
  }
  return void 0;
}
var TRPCError = class extends Error {
  constructor(opts) {
    const code = opts.code;
    const message = opts.message ?? getMessageFromUnknownError(opts.cause, code);
    const cause = opts.cause !== void 0 ? getErrorFromUnknown(opts.cause) : void 0;
    super(message, {
      cause
    });
    this.code = code;
    this.cause = cause;
    this.name = "TRPCError";
    Object.setPrototypeOf(this, new.target.prototype);
  }
};

// node_modules/@trpc/server/dist/codes-52c11119.mjs
function invert(obj) {
  const newObj = /* @__PURE__ */ Object.create(null);
  for (const key in obj) {
    const v = obj[key];
    newObj[v] = key;
  }
  return newObj;
}
var TRPC_ERROR_CODES_BY_KEY = {
  /**
  * Invalid JSON was received by the server.
  * An error occurred on the server while parsing the JSON text.
  */
  PARSE_ERROR: -32700,
  /**
  * The JSON sent is not a valid Request object.
  */
  BAD_REQUEST: -32600,
  /**
  * Internal JSON-RPC error.
  */
  INTERNAL_SERVER_ERROR: -32603,
  // Implementation specific errors
  UNAUTHORIZED: -32001,
  FORBIDDEN: -32003,
  NOT_FOUND: -32004,
  METHOD_NOT_SUPPORTED: -32005,
  TIMEOUT: -32008,
  CONFLICT: -32009,
  PRECONDITION_FAILED: -32012,
  PAYLOAD_TOO_LARGE: -32013,
  TOO_MANY_REQUESTS: -32029,
  CLIENT_CLOSED_REQUEST: -32099
};
var TRPC_ERROR_CODES_BY_NUMBER = invert(TRPC_ERROR_CODES_BY_KEY);

// node_modules/@trpc/server/dist/index-972002da.mjs
var noop = () => {
};
function createInnerProxy(callback, path) {
  const proxy = new Proxy(noop, {
    get(_obj, key) {
      if (typeof key !== "string" || key === "then") {
        return void 0;
      }
      return createInnerProxy(callback, [
        ...path,
        key
      ]);
    },
    apply(_1, _2, args) {
      return callback({
        args,
        path
      });
    }
  });
  return proxy;
}
var createRecursiveProxy = (callback) => createInnerProxy(callback, []);
var createFlatProxy = (callback) => {
  return new Proxy(noop, {
    get(_obj, name) {
      if (typeof name !== "string" || name === "then") {
        return void 0;
      }
      return callback(name);
    }
  });
};

// node_modules/@trpc/server/dist/config-4ca0221b.mjs
function getDataTransformer(transformer) {
  if ("input" in transformer) {
    return transformer;
  }
  return {
    input: transformer,
    output: transformer
  };
}
var defaultTransformer = {
  _default: true,
  input: {
    serialize: (obj) => obj,
    deserialize: (obj) => obj
  },
  output: {
    serialize: (obj) => obj,
    deserialize: (obj) => obj
  }
};
var defaultFormatter = ({ shape }) => {
  return shape;
};
var TRPC_ERROR_CODES_BY_NUMBER2 = invert(TRPC_ERROR_CODES_BY_KEY);
var JSONRPC2_TO_HTTP_CODE = {
  PARSE_ERROR: 400,
  BAD_REQUEST: 400,
  NOT_FOUND: 404,
  INTERNAL_SERVER_ERROR: 500,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  TIMEOUT: 408,
  CONFLICT: 409,
  CLIENT_CLOSED_REQUEST: 499,
  PRECONDITION_FAILED: 412,
  PAYLOAD_TOO_LARGE: 413,
  METHOD_NOT_SUPPORTED: 405,
  TOO_MANY_REQUESTS: 429
};
function getStatusCodeFromKey(code) {
  return JSONRPC2_TO_HTTP_CODE[code] ?? 500;
}
function getHTTPStatusCode(json) {
  const arr = Array.isArray(json) ? json : [
    json
  ];
  const httpStatuses = new Set(arr.map((res) => {
    if ("error" in res) {
      const data = res.error.data;
      if (typeof data.httpStatus === "number") {
        return data.httpStatus;
      }
      const code = TRPC_ERROR_CODES_BY_NUMBER2[res.error.code];
      return getStatusCodeFromKey(code);
    }
    return 200;
  }));
  if (httpStatuses.size !== 1) {
    return 207;
  }
  const httpStatus = httpStatuses.values().next().value;
  return httpStatus;
}
function getHTTPStatusCodeFromError(error) {
  const { code } = error;
  return getStatusCodeFromKey(code);
}
function omitPrototype(obj) {
  return Object.assign(/* @__PURE__ */ Object.create(null), obj);
}
var procedureTypes = [
  "query",
  "mutation",
  "subscription"
];
function isRouter(procedureOrRouter) {
  return "router" in procedureOrRouter._def;
}
var emptyRouter = {
  _ctx: null,
  _errorShape: null,
  _meta: null,
  queries: {},
  mutations: {},
  subscriptions: {},
  errorFormatter: defaultFormatter,
  transformer: defaultTransformer
};
var reservedWords = [
  /**
  * Then is a reserved word because otherwise we can't return a promise that returns a Proxy
  * since JS will think that `.then` is something that exists
  */
  "then"
];
function createRouterFactory(config) {
  return function createRouterInner(procedures) {
    const reservedWordsUsed = new Set(Object.keys(procedures).filter((v) => reservedWords.includes(v)));
    if (reservedWordsUsed.size > 0) {
      throw new Error("Reserved words used in `router({})` call: " + Array.from(reservedWordsUsed).join(", "));
    }
    const routerProcedures = omitPrototype({});
    function recursiveGetPaths(procedures2, path = "") {
      for (const [key, procedureOrRouter] of Object.entries(procedures2 ?? {})) {
        const newPath = `${path}${key}`;
        if (isRouter(procedureOrRouter)) {
          recursiveGetPaths(procedureOrRouter._def.procedures, `${newPath}.`);
          continue;
        }
        if (routerProcedures[newPath]) {
          throw new Error(`Duplicate key: ${newPath}`);
        }
        routerProcedures[newPath] = procedureOrRouter;
      }
    }
    recursiveGetPaths(procedures);
    const _def = {
      _config: config,
      router: true,
      procedures: routerProcedures,
      ...emptyRouter,
      record: procedures,
      queries: Object.entries(routerProcedures).filter((pair) => pair[1]._def.query).reduce((acc, [key, val]) => ({
        ...acc,
        [key]: val
      }), {}),
      mutations: Object.entries(routerProcedures).filter((pair) => pair[1]._def.mutation).reduce((acc, [key, val]) => ({
        ...acc,
        [key]: val
      }), {}),
      subscriptions: Object.entries(routerProcedures).filter((pair) => pair[1]._def.subscription).reduce((acc, [key, val]) => ({
        ...acc,
        [key]: val
      }), {})
    };
    const router2 = {
      ...procedures,
      _def,
      createCaller(ctx) {
        const proxy = createRecursiveProxy(({ path, args }) => {
          if (path.length === 1 && procedureTypes.includes(path[0])) {
            return callProcedure({
              procedures: _def.procedures,
              path: args[0],
              rawInput: args[1],
              ctx,
              type: path[0]
            });
          }
          const fullPath = path.join(".");
          const procedure = _def.procedures[fullPath];
          let type = "query";
          if (procedure._def.mutation) {
            type = "mutation";
          } else if (procedure._def.subscription) {
            type = "subscription";
          }
          return procedure({
            path: fullPath,
            rawInput: args[0],
            ctx,
            type
          });
        });
        return proxy;
      },
      getErrorShape(opts) {
        const { path, error } = opts;
        const { code } = opts.error;
        const shape = {
          message: error.message,
          code: TRPC_ERROR_CODES_BY_KEY[code],
          data: {
            code,
            httpStatus: getHTTPStatusCodeFromError(error)
          }
        };
        if (config.isDev && typeof opts.error.stack === "string") {
          shape.data.stack = opts.error.stack;
        }
        if (typeof path === "string") {
          shape.data.path = path;
        }
        return this._def._config.errorFormatter({
          ...opts,
          shape
        });
      }
    };
    return router2;
  };
}
function callProcedure(opts) {
  const { type, path } = opts;
  if (!(path in opts.procedures) || !opts.procedures[path]?._def[type]) {
    throw new TRPCError({
      code: "NOT_FOUND",
      message: `No "${type}"-procedure on path "${path}"`
    });
  }
  const procedure = opts.procedures[path];
  return procedure(opts);
}
var isServerDefault = typeof window === "undefined" || "Deno" in window || globalThis.process?.env?.NODE_ENV === "test" || !!globalThis.process?.env?.JEST_WORKER_ID;

// node_modules/@trpc/server/dist/index.mjs
function getParseFn(procedureParser) {
  const parser = procedureParser;
  if (typeof parser === "function") {
    return parser;
  }
  if (typeof parser.parseAsync === "function") {
    return parser.parseAsync.bind(parser);
  }
  if (typeof parser.parse === "function") {
    return parser.parse.bind(parser);
  }
  if (typeof parser.validateSync === "function") {
    return parser.validateSync.bind(parser);
  }
  if (typeof parser.create === "function") {
    return parser.create.bind(parser);
  }
  throw new Error("Could not find a validator fn");
}
function mergeWithoutOverrides(obj1, ...objs) {
  const newObj = Object.assign(/* @__PURE__ */ Object.create(null), obj1);
  for (const overrides of objs) {
    for (const key in overrides) {
      if (key in newObj && newObj[key] !== overrides[key]) {
        throw new Error(`Duplicate key ${key}`);
      }
      newObj[key] = overrides[key];
    }
  }
  return newObj;
}
function createMiddlewareFactory() {
  function createMiddlewareInner(middlewares) {
    return {
      _middlewares: middlewares,
      unstable_pipe(middlewareBuilderOrFn) {
        const pipedMiddleware = "_middlewares" in middlewareBuilderOrFn ? middlewareBuilderOrFn._middlewares : [
          middlewareBuilderOrFn
        ];
        return createMiddlewareInner([
          ...middlewares,
          ...pipedMiddleware
        ]);
      }
    };
  }
  function createMiddleware(fn) {
    return createMiddlewareInner([
      fn
    ]);
  }
  return createMiddleware;
}
function isPlainObject(obj) {
  return obj && typeof obj === "object" && !Array.isArray(obj);
}
function createInputMiddleware(parse) {
  const inputMiddleware = async ({ next, rawInput, input }) => {
    let parsedInput;
    try {
      parsedInput = await parse(rawInput);
    } catch (cause) {
      throw new TRPCError({
        code: "BAD_REQUEST",
        cause: getCauseFromUnknown(cause)
      });
    }
    const combinedInput = isPlainObject(input) && isPlainObject(parsedInput) ? {
      ...input,
      ...parsedInput
    } : parsedInput;
    return next({
      input: combinedInput
    });
  };
  inputMiddleware._type = "input";
  return inputMiddleware;
}
function createOutputMiddleware(parse) {
  const outputMiddleware = async ({ next }) => {
    const result = await next();
    if (!result.ok) {
      return result;
    }
    try {
      const data = await parse(result.data);
      return {
        ...result,
        data
      };
    } catch (cause) {
      throw new TRPCError({
        message: "Output validation failed",
        code: "INTERNAL_SERVER_ERROR",
        cause: getCauseFromUnknown(cause)
      });
    }
  };
  outputMiddleware._type = "output";
  return outputMiddleware;
}
var middlewareMarker = "middlewareMarker";
function createNewBuilder(def1, def2) {
  const { middlewares = [], inputs, ...rest } = def2;
  return createBuilder({
    ...mergeWithoutOverrides(def1, rest),
    inputs: [
      ...def1.inputs,
      ...inputs ?? []
    ],
    middlewares: [
      ...def1.middlewares,
      ...middlewares
    ]
  });
}
function createBuilder(initDef) {
  const _def = initDef || {
    inputs: [],
    middlewares: []
  };
  return {
    _def,
    input(input) {
      const parser = getParseFn(input);
      return createNewBuilder(_def, {
        inputs: [
          input
        ],
        middlewares: [
          createInputMiddleware(parser)
        ]
      });
    },
    output(output) {
      const parseOutput = getParseFn(output);
      return createNewBuilder(_def, {
        output,
        middlewares: [
          createOutputMiddleware(parseOutput)
        ]
      });
    },
    meta(meta) {
      return createNewBuilder(_def, {
        meta
      });
    },
    /**
    * @deprecated
    * This functionality is deprecated and will be removed in the next major version.
    */
    unstable_concat(builder) {
      return createNewBuilder(_def, builder._def);
    },
    use(middlewareBuilderOrFn) {
      const middlewares = "_middlewares" in middlewareBuilderOrFn ? middlewareBuilderOrFn._middlewares : [
        middlewareBuilderOrFn
      ];
      return createNewBuilder(_def, {
        middlewares
      });
    },
    query(resolver) {
      return createResolver({
        ..._def,
        query: true
      }, resolver);
    },
    mutation(resolver) {
      return createResolver({
        ..._def,
        mutation: true
      }, resolver);
    },
    subscription(resolver) {
      return createResolver({
        ..._def,
        subscription: true
      }, resolver);
    }
  };
}
function createResolver(_def, resolver) {
  const finalBuilder = createNewBuilder(_def, {
    resolver,
    middlewares: [
      async function resolveMiddleware(opts) {
        const data = await resolver(opts);
        return {
          marker: middlewareMarker,
          ok: true,
          data,
          ctx: opts.ctx
        };
      }
    ]
  });
  return createProcedureCaller(finalBuilder._def);
}
var codeblock = `
If you want to call this function on the server, you do the following:
This is a client-only function.

const caller = appRouter.createCaller({
  /* ... your context */
});

const result = await caller.call('myProcedure', input);
`.trim();
function createProcedureCaller(_def) {
  const procedure = async function resolve(opts) {
    if (!opts || !("rawInput" in opts)) {
      throw new Error(codeblock);
    }
    const callRecursive = async (callOpts = {
      index: 0,
      ctx: opts.ctx
    }) => {
      try {
        const middleware2 = _def.middlewares[callOpts.index];
        const result2 = await middleware2({
          ctx: callOpts.ctx,
          type: opts.type,
          path: opts.path,
          rawInput: opts.rawInput,
          meta: _def.meta,
          input: callOpts.input,
          next: async (nextOpts) => {
            return await callRecursive({
              index: callOpts.index + 1,
              ctx: nextOpts && "ctx" in nextOpts ? {
                ...callOpts.ctx,
                ...nextOpts.ctx
              } : callOpts.ctx,
              input: nextOpts && "input" in nextOpts ? nextOpts.input : callOpts.input
            });
          }
        });
        return result2;
      } catch (cause) {
        return {
          ok: false,
          error: getTRPCErrorFromUnknown(cause),
          marker: middlewareMarker
        };
      }
    };
    const result = await callRecursive();
    if (!result) {
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "No result from middlewares - did you forget to `return next()`?"
      });
    }
    if (!result.ok) {
      throw result.error;
    }
    return result.data;
  };
  procedure._def = _def;
  procedure.meta = _def.meta;
  return procedure;
}
function mergeRouters(...routerList) {
  const record = mergeWithoutOverrides({}, ...routerList.map((r) => r._def.record));
  const errorFormatter = routerList.reduce((currentErrorFormatter, nextRouter) => {
    if (nextRouter._def._config.errorFormatter && nextRouter._def._config.errorFormatter !== defaultFormatter) {
      if (currentErrorFormatter !== defaultFormatter && currentErrorFormatter !== nextRouter._def._config.errorFormatter) {
        throw new Error("You seem to have several error formatters");
      }
      return nextRouter._def._config.errorFormatter;
    }
    return currentErrorFormatter;
  }, defaultFormatter);
  const transformer = routerList.reduce((prev, current) => {
    if (current._def._config.transformer && current._def._config.transformer !== defaultTransformer) {
      if (prev !== defaultTransformer && prev !== current._def._config.transformer) {
        throw new Error("You seem to have several transformers");
      }
      return current._def._config.transformer;
    }
    return prev;
  }, defaultTransformer);
  const router2 = createRouterFactory({
    errorFormatter,
    transformer,
    isDev: routerList.some((r) => r._def._config.isDev),
    allowOutsideOfServer: routerList.some((r) => r._def._config.allowOutsideOfServer),
    isServer: routerList.some((r) => r._def._config.isServer),
    $types: routerList[0]?._def._config.$types
  })(record);
  return router2;
}
var TRPCBuilder = class {
  context() {
    return new TRPCBuilder();
  }
  meta() {
    return new TRPCBuilder();
  }
  create(options) {
    return createTRPCInner()(options);
  }
};
var initTRPC = new TRPCBuilder();
function createTRPCInner() {
  return function initTRPCInner(runtime) {
    const errorFormatter = runtime?.errorFormatter ?? defaultFormatter;
    const transformer = getDataTransformer(runtime?.transformer ?? defaultTransformer);
    const config = {
      transformer,
      isDev: runtime?.isDev ?? globalThis.process?.env?.NODE_ENV !== "production",
      allowOutsideOfServer: runtime?.allowOutsideOfServer ?? false,
      errorFormatter,
      isServer: runtime?.isServer ?? isServerDefault,
      /**
      * @internal
      */
      $types: createFlatProxy((key) => {
        throw new Error(`Tried to access "$types.${key}" which is not available at runtime`);
      })
    };
    {
      const isServer = runtime?.isServer ?? isServerDefault;
      if (!isServer && runtime?.allowOutsideOfServer !== true) {
        throw new Error(`You're trying to use @trpc/server in a non-server environment. This is not supported by default.`);
      }
    }
    return {
      /**
      * These are just types, they can't be used
      * @internal
      */
      _config: config,
      /**
      * Builder object for creating procedures
      */
      procedure: createBuilder(),
      /**
      * Create reusable middlewares
      */
      middleware: createMiddlewareFactory(),
      /**
      * Create a router
      */
      router: createRouterFactory(config),
      /**
      * Merge Routers
      */
      mergeRouters
    };
  };
}

// node_modules/@trpc/server/dist/transformTRPCResponse-7a73a2df.mjs
function transformTRPCResponseItem(router2, item) {
  if ("error" in item) {
    return {
      ...item,
      error: router2._def._config.transformer.output.serialize(item.error)
    };
  }
  if ("data" in item.result) {
    return {
      ...item,
      result: {
        ...item.result,
        data: router2._def._config.transformer.output.serialize(item.result.data)
      }
    };
  }
  return item;
}
function transformTRPCResponse(router2, itemOrItems) {
  return Array.isArray(itemOrItems) ? itemOrItems.map((item) => transformTRPCResponseItem(router2, item)) : transformTRPCResponseItem(router2, itemOrItems);
}

// node_modules/@trpc/server/dist/resolveHTTPResponse-64517f5d.mjs
var HTTP_METHOD_PROCEDURE_TYPE_MAP = {
  GET: "query",
  POST: "mutation"
};
function getRawProcedureInputOrThrow(req) {
  try {
    if (req.method === "GET") {
      if (!req.query.has("input")) {
        return void 0;
      }
      const raw = req.query.get("input");
      return JSON.parse(raw);
    }
    if (typeof req.body === "string") {
      return req.body.length === 0 ? void 0 : JSON.parse(req.body);
    }
    return req.body;
  } catch (err) {
    throw new TRPCError({
      code: "PARSE_ERROR",
      cause: getCauseFromUnknown(err)
    });
  }
}
async function resolveHTTPResponse(opts) {
  const { createContext: createContext2, onError, router: router2, req } = opts;
  const batchingEnabled = opts.batching?.enabled ?? true;
  if (req.method === "HEAD") {
    return {
      status: 204
    };
  }
  const type = HTTP_METHOD_PROCEDURE_TYPE_MAP[req.method] ?? "unknown";
  let ctx = void 0;
  let paths = void 0;
  const isBatchCall = !!req.query.get("batch");
  function endResponse(untransformedJSON, errors) {
    let status = getHTTPStatusCode(untransformedJSON);
    const headers = {
      "Content-Type": "application/json"
    };
    const meta = opts.responseMeta?.({
      ctx,
      paths,
      type,
      data: Array.isArray(untransformedJSON) ? untransformedJSON : [
        untransformedJSON
      ],
      errors
    }) ?? {};
    for (const [key, value] of Object.entries(meta.headers ?? {})) {
      headers[key] = value;
    }
    if (meta.status) {
      status = meta.status;
    }
    const transformedJSON = transformTRPCResponse(router2, untransformedJSON);
    const body = JSON.stringify(transformedJSON);
    return {
      body,
      status,
      headers
    };
  }
  try {
    if (opts.error) {
      throw opts.error;
    }
    if (isBatchCall && !batchingEnabled) {
      throw new Error(`Batching is not enabled on the server`);
    }
    if (type === "subscription") {
      throw new TRPCError({
        message: "Subscriptions should use wsLink",
        code: "METHOD_NOT_SUPPORTED"
      });
    }
    if (type === "unknown") {
      throw new TRPCError({
        message: `Unexpected request method ${req.method}`,
        code: "METHOD_NOT_SUPPORTED"
      });
    }
    const rawInput = getRawProcedureInputOrThrow(req);
    paths = isBatchCall ? opts.path.split(",") : [
      opts.path
    ];
    ctx = await createContext2();
    const deserializeInputValue = (rawValue) => {
      return typeof rawValue !== "undefined" ? router2._def._config.transformer.input.deserialize(rawValue) : rawValue;
    };
    const getInputs = () => {
      if (!isBatchCall) {
        return {
          0: deserializeInputValue(rawInput)
        };
      }
      if (rawInput == null || typeof rawInput !== "object" || Array.isArray(rawInput)) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: '"input" needs to be an object when doing a batch call'
        });
      }
      const input = {};
      for (const key in rawInput) {
        const k = key;
        const rawValue = rawInput[k];
        const value = deserializeInputValue(rawValue);
        input[k] = value;
      }
      return input;
    };
    const inputs = getInputs();
    const rawResults = await Promise.all(paths.map(async (path, index) => {
      const input = inputs[index];
      try {
        const output = await callProcedure({
          procedures: router2._def.procedures,
          path,
          rawInput: input,
          ctx,
          type
        });
        return {
          input,
          path,
          data: output
        };
      } catch (cause) {
        const error = getTRPCErrorFromUnknown(cause);
        onError?.({
          error,
          path,
          input,
          ctx,
          type,
          req
        });
        return {
          input,
          path,
          error
        };
      }
    }));
    const errors = rawResults.flatMap((obj) => obj.error ? [
      obj.error
    ] : []);
    const resultEnvelopes = rawResults.map((obj) => {
      const { path, input } = obj;
      if (obj.error) {
        return {
          error: router2.getErrorShape({
            error: obj.error,
            type,
            path,
            input,
            ctx
          })
        };
      } else {
        return {
          result: {
            data: obj.data
          }
        };
      }
    });
    const result = isBatchCall ? resultEnvelopes : resultEnvelopes[0];
    return endResponse(result, errors);
  } catch (cause) {
    const error = getTRPCErrorFromUnknown(cause);
    onError?.({
      error,
      path: void 0,
      input: void 0,
      ctx,
      type,
      req
    });
    return endResponse({
      error: router2.getErrorShape({
        error,
        type,
        path: void 0,
        input: void 0,
        ctx
      })
    }, [
      error
    ]);
  }
}

// node_modules/@trpc/server/dist/adapters/aws-lambda/index.mjs
function isPayloadV1(event) {
  return determinePayloadFormat(event) == "1.0";
}
function isPayloadV2(event) {
  return determinePayloadFormat(event) == "2.0";
}
function determinePayloadFormat(event) {
  const unknownEvent = event;
  if (typeof unknownEvent.version === "undefined") {
    return "1.0";
  } else {
    if ([
      "1.0",
      "2.0"
    ].includes(unknownEvent.version)) {
      return unknownEvent.version;
    } else {
      return "custom";
    }
  }
}
function getHTTPMethod(event) {
  if (isPayloadV1(event)) {
    return event.httpMethod;
  }
  if (isPayloadV2(event)) {
    return event.requestContext.http.method;
  }
  throw new TRPCError({
    code: "INTERNAL_SERVER_ERROR",
    message: UNKNOWN_PAYLOAD_FORMAT_VERSION_ERROR_MESSAGE
  });
}
function getPath(event) {
  if (isPayloadV1(event)) {
    const matches = event.resource.matchAll(/\{(.*?)\}/g);
    for (const match of matches) {
      const group = match[1];
      if (group.includes("+") && event.pathParameters) {
        return event.pathParameters[group.replace("+", "")] || "";
      }
    }
    return event.path.slice(1);
  }
  if (isPayloadV2(event)) {
    const matches1 = event.routeKey.matchAll(/\{(.*?)\}/g);
    for (const match1 of matches1) {
      const group1 = match1[1];
      if (group1.includes("+") && event.pathParameters) {
        return event.pathParameters[group1.replace("+", "")] || "";
      }
    }
    return event.rawPath.slice(1);
  }
  throw new TRPCError({
    code: "INTERNAL_SERVER_ERROR",
    message: UNKNOWN_PAYLOAD_FORMAT_VERSION_ERROR_MESSAGE
  });
}
function transformHeaders(headers) {
  const obj = {};
  for (const [key, value] of Object.entries(headers)) {
    if (typeof value === "undefined") {
      continue;
    }
    obj[key] = Array.isArray(value) ? value.join(",") : value;
  }
  return obj;
}
var UNKNOWN_PAYLOAD_FORMAT_VERSION_ERROR_MESSAGE = "Custom payload format version not handled by this adapter. Please use either 1.0 or 2.0. More information herehttps://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-develop-integrations-lambda.html";
function lambdaEventToHTTPRequest(event) {
  const query = new URLSearchParams();
  for (const [key, value] of Object.entries(event.queryStringParameters ?? {})) {
    if (typeof value !== "undefined") {
      query.append(key, value);
    }
  }
  let body;
  if (event.body && event.isBase64Encoded) {
    body = Buffer.from(event.body, "base64").toString("utf8");
  } else {
    body = event.body;
  }
  return {
    method: getHTTPMethod(event),
    query,
    headers: event.headers,
    body
  };
}
function tRPCOutputToAPIGatewayOutput(event, response) {
  if (isPayloadV1(event)) {
    const resp = {
      statusCode: response.status,
      body: response.body ?? "",
      headers: transformHeaders(response.headers ?? {})
    };
    return resp;
  } else if (isPayloadV2(event)) {
    const resp1 = {
      statusCode: response.status,
      body: response.body ?? void 0,
      headers: transformHeaders(response.headers ?? {})
    };
    return resp1;
  } else {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: UNKNOWN_PAYLOAD_FORMAT_VERSION_ERROR_MESSAGE
    });
  }
}
function awsLambdaRequestHandler(opts) {
  return async (event, context) => {
    const req = lambdaEventToHTTPRequest(event);
    const path = getPath(event);
    const createContext2 = async function _createContext() {
      return await opts.createContext?.({
        event,
        context
      });
    };
    const response = await resolveHTTPResponse({
      router: opts.router,
      batching: opts.batching,
      responseMeta: opts?.responseMeta,
      createContext: createContext2,
      req,
      path,
      error: null,
      onError(o) {
        opts?.onError?.({
          ...o,
          req: event
        });
      }
    });
    return tRPCOutputToAPIGatewayOutput(event, response);
  };
}

// src/server/services/Products/CompositionRoot.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");

// src/server/services/Products/Adapters/Logger/Logger.adapter.ts
var Logger = class {
  log(message) {
    console.log("logger", message);
  }
};

// src/server/utilities/dynamo.utility.ts
var import_util_dynamodb = require("@aws-sdk/util-dynamodb");
var GenerateDynamoSearchItem = (dbName, key) => {
  return {
    Key: (0, import_util_dynamodb.marshall)({
      id: key
    }),
    TableName: dbName
  };
};
var TransformDynamoItem = (item) => {
  if (Array.isArray(item)) {
    return item.map((i) => (0, import_util_dynamodb.unmarshall)(i));
  }
  return item ? (0, import_util_dynamodb.unmarshall)(item) : null;
};

// src/server/services/Products/Adapters/ProductGetter/ProductGetter.adapter.ts
var ProductGetter = class {
  constructor(productService2, dynamoClient2) {
    this.productService = productService2;
    this.dynamoClient = dynamoClient2;
    this.productTable = process.env.TODO_TABLE_NAME;
  }
  async getProducts() {
    const scanProducts = {
      TableName: this.productTable
    };
    const { Items: dynamoItems } = await this.dynamoClient.scan(scanProducts);
    const result = TransformDynamoItem(dynamoItems);
    return this.productService.getProducts(result);
  }
  async getProductById(id) {
    const { Item: dynamoItem } = await this.dynamoClient.getItem(
      GenerateDynamoSearchItem(this.productTable, id)
    );
    const result = TransformDynamoItem(dynamoItem);
    return this.productService.getProductById(result);
  }
};

// src/server/services/Products/Domain/Product.service.ts
var ProductService = class {
  constructor(logger2) {
    this.logger = logger2;
  }
  async getProducts(products) {
    this.logger.log("getProducts");
    return products;
  }
  async getProductById(product) {
    this.logger.log("getProductById");
    return product;
  }
};

// src/server/services/Products/CompositionRoot.ts
var dynamoClient = new import_client_dynamodb.DynamoDB({
  region: process.env.AWS_REGION
});
var logger = new Logger();
var productService = new ProductService(logger);
var productGetter = new ProductGetter(productService, dynamoClient);

// src/server/lambdas/Product/get-all-products.lambda.ts
function sendError(message) {
  return {
    statusCode: 400,
    body: JSON.stringify({ message })
  };
}
async function getProducts(_event) {
  try {
    const result = await productGetter.getProducts();
    return {
      statusCode: 200,
      body: JSON.stringify(result)
    };
  } catch (err) {
    return sendError("error in getProduct");
  }
}

// src/server/lambdas/Product/get-product.lambda.ts
function sendError2(message) {
  return {
    statusCode: 400,
    body: JSON.stringify({ message })
  };
}
async function getProduct(event) {
  try {
    const { pathParameters } = event;
    console.log("error");
    if (!pathParameters?.id)
      return sendError2("invalid request");
    const id = pathParameters.id;
    const result = await productGetter.getProductById(id);
    return {
      statusCode: 200,
      body: JSON.stringify(result)
    };
  } catch (err) {
    return sendError2("error in getProduct");
  }
}

// src/server/server.ts
var t = initTRPC.create();
var { router } = t;
var { middleware } = t;
var publicProcedure = t.procedure;
var appRouter = router({
  getProducts: publicProcedure.query(async () => getProducts),
  getProductById: publicProcedure.query(async () => getProduct)
});
var createContext = () => ({});
var handler = awsLambdaRequestHandler({
  router: appRouter,
  createContext,
  responseMeta: () => ({
    headers: {
      "Access-Control-Allow-Origin": "*"
    }
  })
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler,
  middleware,
  publicProcedure,
  router
});
