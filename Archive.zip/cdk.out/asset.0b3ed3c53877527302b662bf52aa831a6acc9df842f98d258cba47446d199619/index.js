"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/server/lambdas/get-product.lambda.ts
var get_product_lambda_exports = {};
__export(get_product_lambda_exports, {
  getProduct: () => getProduct
});
module.exports = __toCommonJS(get_product_lambda_exports);

// src/server/services/Products/Adapters/Logger.adapter.ts
var Logger = class {
  log(message) {
    console.log("logger", message);
  }
};

// src/server/services/Products/Domain/Product.service.ts
var ProductService = class {
  constructor(obtainer2, logger2) {
    this.obtainer = obtainer2;
    this.logger = logger2;
    this.productTable = process.env.TODO_TABLE_NAME;
  }
  async getProducts() {
    this.logger.log("getProducts");
    try {
      const result = await this.obtainer.getItems(this.productTable);
      return result;
    } catch (err) {
      this.logger.log("Error in getProducts");
      return [];
    }
  }
  async getProductById(id) {
    this.logger.log("getProductById");
    try {
      const result = await this.obtainer.getItem(this.productTable, id);
      return result;
    } catch (err) {
      this.logger.log("Error in getProductById");
      return {};
    }
  }
};

// src/server/services/Storage/Adapters/Obtainer.adapter.ts
var Obtainer = class {
  constructor(storageService2) {
    this.storageService = storageService2;
  }
  getItem(dbName, key) {
    return this.storageService.getItem(dbName, key);
  }
  getItems(dbName) {
    return this.storageService.getItems(dbName);
  }
};

// src/server/services/Storage/Domain/Storage.service.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_util_dynamodb = require("@aws-sdk/util-dynamodb");
var StorageService = class {
  constructor() {
    this.dynamoClient = new import_client_dynamodb.DynamoDB({
      region: "us-east-1"
    });
  }
  async getItem(dbName, key) {
    const getProductItem = {
      Key: (0, import_util_dynamodb.marshall)({
        id: key
      }),
      TableName: dbName
    };
    const { Item: dynamoItem } = await this.dynamoClient.getItem(
      getProductItem
    );
    const todo = dynamoItem ? (0, import_util_dynamodb.unmarshall)(dynamoItem) : null;
    return todo;
  }
  async getItems(dbName) {
    const scanProducts = {
      TableName: dbName
    };
    const { Items: dynamoItems } = await this.dynamoClient.scan(scanProducts);
    const productData = dynamoItems ? dynamoItems.map((item) => (0, import_util_dynamodb.unmarshall)(item)) : [];
    return productData;
  }
};

// src/server/services/Products/CompositionRoot.ts
var storageService = new StorageService();
var obtainer = new Obtainer(storageService);
var logger = new Logger();
var productService = new ProductService(obtainer, logger);

// src/server/lambdas/get-product.lambda.ts
function sendError(message) {
  return {
    statusCode: 400,
    body: JSON.stringify({ message })
  };
}
async function getProduct(event) {
  try {
    const { pathParameters } = event;
    console.log("error");
    if (!pathParameters?.id)
      return sendError("invalid request");
    const id = pathParameters.id;
    const result = await productService.getProductById(id);
    return {
      statusCode: 200,
      body: JSON.stringify(result)
    };
  } catch (err) {
    return sendError("error in getProduct");
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getProduct
});
