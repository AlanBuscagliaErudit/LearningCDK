"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/server/lambdas/Product/get-all-products.lambda.ts
var get_all_products_lambda_exports = {};
__export(get_all_products_lambda_exports, {
  getProducts: () => getProducts
});
module.exports = __toCommonJS(get_all_products_lambda_exports);

// src/server/services/Products/CompositionRoot.ts
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");

// src/server/services/Products/Adapters/Logger.adapter.ts
var Logger = class {
  log(message) {
    console.log("logger", message);
  }
};

// src/server/utilities/dynamo.utility.ts
var import_util_dynamodb = require("@aws-sdk/util-dynamodb");
var GenerateDynamoSearchItem = (dbName, key) => {
  return {
    Key: (0, import_util_dynamodb.marshall)({
      id: key
    }),
    TableName: dbName
  };
};
var TransformDynamoItem = (item) => {
  if (Array.isArray(item)) {
    return item.map((i) => (0, import_util_dynamodb.unmarshall)(i));
  }
  return item ? (0, import_util_dynamodb.unmarshall)(item) : null;
};

// src/server/services/Products/Adapters/ProductGetter.adapter.ts
var ProductGetter = class {
  constructor(productService2, dynamoClient2) {
    this.productService = productService2;
    this.dynamoClient = dynamoClient2;
    this.productTable = process.env.TODO_TABLE_NAME;
  }
  async getProducts() {
    const scanProducts = {
      TableName: this.productTable
    };
    const { Items: dynamoItems } = await this.dynamoClient.scan(scanProducts);
    const result = TransformDynamoItem(dynamoItems);
    return this.productService.getProducts(result);
  }
  async getProductById(id) {
    const { Item: dynamoItem } = await this.dynamoClient.getItem(
      GenerateDynamoSearchItem(this.productTable, id)
    );
    const result = TransformDynamoItem(dynamoItem);
    return this.productService.getProductById(result);
  }
};

// src/server/services/Products/Domain/Product.service.ts
var ProductService = class {
  constructor(logger2) {
    this.logger = logger2;
  }
  async getProducts(products) {
    this.logger.log("getProducts");
    return products;
  }
  async getProductById(product) {
    this.logger.log("getProductById");
    return product;
  }
};

// src/server/services/Products/CompositionRoot.ts
var dynamoClient = new import_client_dynamodb.DynamoDB({
  region: "us-east-1"
});
var logger = new Logger();
var productService = new ProductService(logger);
var productGetter = new ProductGetter(productService, dynamoClient);

// src/server/lambdas/Product/get-all-products.lambda.ts
function sendError(message) {
  return {
    statusCode: 400,
    body: JSON.stringify({ message })
  };
}
async function getProducts(_event) {
  try {
    const result = await productGetter.getProducts();
    return {
      statusCode: 200,
      body: JSON.stringify(result)
    };
  } catch (err) {
    return sendError("error in getProduct");
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getProducts
});
