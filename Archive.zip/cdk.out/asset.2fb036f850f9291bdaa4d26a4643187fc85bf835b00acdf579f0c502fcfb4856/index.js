"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/server/lambdas/get-all-products.lambda.ts
var get_all_products_lambda_exports = {};
__export(get_all_products_lambda_exports, {
  getProducts: () => getProducts
});
module.exports = __toCommonJS(get_all_products_lambda_exports);
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_util_dynamodb = require("@aws-sdk/util-dynamodb");
async function getProducts(_event) {
  const tableName = process.env.TODO_TABLE_NAME;
  const dynamoClient = new import_client_dynamodb.DynamoDB({
    region: "us-east-1"
  });
  const scanProducts = {
    TableName: tableName
  };
  try {
    const { Items: dynamoItems } = await dynamoClient.scan(scanProducts);
    const productData = dynamoItems ? dynamoItems.map((item) => (0, import_util_dynamodb.unmarshall)(item)) : [];
    return {
      statusCode: 200,
      body: JSON.stringify({ listProducts: productData })
    };
  } catch (err) {
    console.log(err);
    return {
      statusCode: 400,
      body: JSON.stringify({
        message: "something went wrong"
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getProducts
});
