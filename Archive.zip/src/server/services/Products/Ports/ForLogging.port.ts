export interface ForLogging {
  log(message: string): void;
}
